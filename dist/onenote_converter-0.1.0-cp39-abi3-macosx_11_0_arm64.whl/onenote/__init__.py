from .onenote import *

__doc__ = onenote.__doc__
if hasattr(onenote, "__all__"):
    __all__ = onenote.__all__